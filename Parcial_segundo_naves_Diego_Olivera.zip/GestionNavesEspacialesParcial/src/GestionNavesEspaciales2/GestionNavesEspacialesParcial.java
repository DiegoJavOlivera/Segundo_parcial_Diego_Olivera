/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package GestionNavesEspaciales2;

import java.io.IOException;
import modelo.Categoria;
import modelo.Inventario;
import modelo.NaveEspacial;

/**
 *
 * @author Diego
 */
public class GestionNavesEspacialesParcial {

    /**
     * @param args the command line arguments
     */

    public static void main(String[] args) {
        try {
            // Crear un inventario de naves
            Inventario<NaveEspacial> inventarioNaves = new Inventario<>();
            inventarioNaves.agregar(new NaveEspacial(1, "USS Enterprise",100, Categoria.EXPLORACION));
            inventarioNaves.agregar(new NaveEspacial(2, "Millennium Falcon", 61000, Categoria.CARGA));
            inventarioNaves.agregar(new NaveEspacial(3, "TIE Fighter", 21000, Categoria.MILITAR));
            inventarioNaves.agregar(new NaveEspacial(4, "X-Wing", 20000, Categoria.MILITAR));
            inventarioNaves.agregar(new NaveEspacial(5, "Discovery One", 10000, Categoria.EXPLORACION));

                      
            // Mostrar todas las naves en el inventario
            System.out.println("Inventario de naves espaciales:");
            inventarioNaves.paraCadaElemento(naves -> System.out.println(naves));

            // Filtrar naves por categoría MILITAR
            System.out.println("\nNaves de la categoria MILITAR:");
            inventarioNaves.filtrar(nave -> nave.getCategoria() == Categoria.MILITAR)
                            .forEach(System.out::println);

            // Filtrar naves cuyo nombre contiene "Falcon"

            System.out.println("\nNaves cuyo nombre contiene 'Falcon':");
            inventarioNaves.filtrar(naves -> naves.getNombre().contains("Falcon"))
                            .forEach(System.out::println);

            // Ordenar naves de manera natural (por id)
            System.out.println("\n Naves ordenados de manera natural (por id):");
            inventarioNaves.ordenar();
            inventarioNaves.paraCadaElemento(System.out::println);

            // Ordenar naves por nombre utilizando un Comparator
            System.out.println("\naves ordenados por nombre:");
            inventarioNaves.ordenar((nave1, nave2) -> nave1.getNombre().compareTo(nave2.getNombre()));
            inventarioNaves.paraCadaElemento(System.out::println);
            
            // Ordenar naves por tripulacion utilizando un Comparator
            System.out.println("\nNaves ordenadas por tripulacion:");
            inventarioNaves.ordenar((nave1, nave2) -> Integer.compare(nave1.getCapacidad(), nave2.getCapacidad()));
            inventarioNaves.paraCadaElemento(System.out::println);

            // Guardar el inventario en un archivo binario
            inventarioNaves.guardarEnArchivo("src/data/naves.dat");
            // Cargar el inventario desde el archivo binario
            Inventario<NaveEspacial> inventarioCargado = new Inventario<>();
            inventarioCargado.cargarDesdeArchivo("src/data/naves.dat");
            System.out.println("\n naves cargadas desde archivo binario:");
            inventarioCargado.paraCadaElemento(System.out::println);

            // Guardar el inventario en un archivo CSV
            inventarioNaves.guardarEnCSV("src/data/naves.csv"); 

            // Cargar el inventario desde el archivo CSV
            inventarioCargado.cargarDesdeCSV("src/data/naves.csv", NaveEspacial::fromCSV);
            System.out.println("\nnaves cargados desde archivo CSV:");
            inventarioCargado.paraCadaElemento(System.out::println);

        } catch (IOException | ClassNotFoundException e) {
            System.err.println("Error: " + e.getMessage());
        }
    }
}
    

