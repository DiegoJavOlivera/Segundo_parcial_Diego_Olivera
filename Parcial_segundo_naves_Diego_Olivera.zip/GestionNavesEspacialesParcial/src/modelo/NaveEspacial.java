/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

import java.io.Serializable;
import util.CSVSerializable;

/**
 *
 * @author Diego
 */
public class NaveEspacial implements Comparable<NaveEspacial>, Serializable, CSVSerializable {
    private int id;
    private String nombre;
    private int capacidad;
    private Categoria categoria;


    public NaveEspacial(int id, String nombre, int capacidad, Categoria categoria) {
        this.id = id;
        this.nombre = nombre;
        this.capacidad = capacidad;
        this.categoria = categoria;
    }
    
    @Override
    public String toString() {
        return "NaveEspacial{id=" + id + ", nombre='" + nombre + "', capacidad='" + capacidad + "', categoria=" + categoria + "}";
    }
    

    public int getId() {
        return id;
    } 

    public String getNombre() {
        return nombre;
    }

    public int getCapacidad() {
        return capacidad;
    }

    public Categoria getCategoria() {
        return categoria;
    }

    @Override
    public String toCSV() {
        return id + "," + nombre + "," + capacidad + "," + categoria.name();
    }


    public static NaveEspacial fromCSV(String csv) {
        String[] partes = csv.split(",", -1); 
        if (partes.length != 4) {
            throw new IllegalArgumentException("El formato no es válido.");
        }
        int id = Integer.parseInt(partes[0]); 
        String nombre = partes[1]; 
        int capacidad = Integer.parseInt(partes[2]); 
        Categoria categoria = Categoria.valueOf(partes[3].toUpperCase()); 

        return new NaveEspacial(id, nombre, capacidad, categoria); 
    }


    @Override
    public int compareTo(NaveEspacial otro) {
        return Integer.compare(this.id, otro.id);
    }

    
}
