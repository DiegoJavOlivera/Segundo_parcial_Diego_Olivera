/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;



import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Serializable;
import util.CSVSerializable;
import java.util.*;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Predicate;
import service.Serializadora;


public class Inventario<T extends CSVSerializable & Serializable > {
    private List<T> items;

    public Inventario() {
        this.items = new ArrayList<>();
    }

    public void agregar(T item) {
        items.add(item);
    }

    public T obtener(int indice) {
        if (indice >= 0 && indice < items.size()) {
            return items.get(indice);
        } else {
            throw new IndexOutOfBoundsException("Índice fuera de rango");
        }
    }


    public void eliminar(int indice) {
        if (indice >= 0 && indice < items.size()) {
            items.remove(indice);
        } else {
            throw new IndexOutOfBoundsException("Índice fuera de rango");
        }
    }


    public List<T> filtrar(Predicate<T> criterio) {
        List<T> resultado = new ArrayList<>();
        for (T item : items) {
            if (criterio.test(item)) {
                resultado.add(item);
            }
        }
        return resultado;
    }
    
    public List<T> filtrarPorCategoria(Categoria categoria) {
        return filtrar(item -> {
            if (item instanceof NaveEspacial) {
                return ((NaveEspacial) item).getCategoria() == categoria;
            }
            return false;
            });
    }
    
    public List<T> filtrarPorTitulo(String palabra) {
        return filtrar(item -> {
        if (item instanceof NaveEspacial) {
            return ((NaveEspacial) item).getNombre().toLowerCase().contains(palabra.toLowerCase());
        }
        return false;});
    }
    

    public void ordenar(Comparator<? super T> comparator) {
        items.sort(comparator);
    }
      
    public void ordenar() {
        items.sort(null); 
    }

   
    
   public void guardarEnArchivo(String path) {
        try {
            Serializadora.serializarLista(items, path);
            System.out.println("Inventario guardado en binario: " + path);
        } catch (Exception ex) {
            System.out.println("Error!: surgio un error cuando se intento guardar en binario: " + ex.getMessage());
        }
    }
   
    public void cargarDesdeArchivo(String path) {
        try {
            List<T> itemsCargados = Serializadora.deserializarLista(path);
            if (itemsCargados != null) {
                items.clear(); 
                items.addAll(itemsCargados); 
                System.out.println("Inventario cargado de un archivo binario: " + path);
            } else {
                System.out.println("ERROR! El archivo binario no se pudo cargar.");
            }
        } catch (Exception ex) {
            System.out.println("Error! al cargar desde archivo binario: " + ex.getMessage());
        }
    }


    public void guardarEnCSV(String path) throws IOException{
        File archivo = new File(path);

        try (BufferedWriter bw = new BufferedWriter(new FileWriter(archivo))) {

            bw.write("id,titulo,autor,categoria\n");
            for (T item : items) {
                if (item instanceof CSVSerializable) { 
                    bw.write(((CSVSerializable) item).toCSV() + "\n");
                }
            }

            System.out.println("\n Inventario guardado en CSV: " + path);
        } catch (IOException ex) {
            System.out.println("Error cuando se guardo en CSV: " + ex.getMessage());
        }
    }

    public void cargarDesdeCSV(String path, Function<String, T> convertidor) throws IOException, ClassNotFoundException{
        File archivo = new File(path);
         this.items.clear();

        try (BufferedReader br = new BufferedReader(new FileReader(archivo))) {
            String linea;
            br.readLine(); 
            while ((linea = br.readLine()) != null) {
                if (!linea.isBlank()) {
                    try {
                        T item = convertidor.apply(linea);
                        agregar(item);
                    } catch (IllegalArgumentException e) {
                        System.out.println("Error! al procesar linea: " + linea + " - " + e.getMessage());
                    }
                }
            }
            System.out.println(" Inventario cargado en archivo CSV.");
        } catch (IOException e) {
            System.out.println(" Error al cargar desde archivo CSV: " + e.getMessage());
        }
    }


    public List<T> obtenerTodos() {
        return new ArrayList<>(items);
    }
    
    public void paraCadaElemento(Consumer<T> accion) {
        for (T item : items) {
            accion.accept(item);
        }
    }
}