/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package service;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.List;


/**
 *
 * @author Diego
 */
public class Serializadora {
    public static <T extends Serializable> void serializarLista(List<T> lista, String path) {
        try (ObjectOutputStream salida = new ObjectOutputStream(new FileOutputStream(path))) {
            salida.writeObject(lista);
            System.out.println("\nLista serializada y guardada en: " + path);
        } catch (IOException ex) {
            ex.printStackTrace();
            System.out.println("Error al serializar: " + ex.getMessage());
        }
    }

   
    public static <T> List<T> deserializarLista(String path) {
        List<T> toReturn = null;
        try (ObjectInputStream entrada = new ObjectInputStream(new FileInputStream(path))) {
            toReturn = (List<T>) entrada.readObject();
            System.out.println("\n Lista deserializada desde " + path);
        } catch (IOException | ClassNotFoundException ex) {
            System.out.println("Error al deseriaizar: " + ex.getMessage());
        }
        return toReturn;
    }
}
